package com.java8.CapgeminiFirst10;

import java.util.Arrays;
import java.util.List;

public class ContainZeroAtLast37 {
    public static void main(String[] args) {

        List<Integer> list= Arrays.asList(10 , 15 ,29 ,30 ,40 ,20 ,50 ,18);

        list.stream().filter(num-> num%10 ==0).forEach(e->System.out.println(e));

    }
}
