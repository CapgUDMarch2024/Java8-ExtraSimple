package com.java8.CapgeminiFirst10;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
// Finding the second largest number using Stream API
public class N34_SecondMaxElementInList {
    public static void main(String[] args) {

        List<Integer> numbers = Arrays.asList(1, 3, 4, 5, 6, 8, 7, 2);

        Optional<Integer> secondLargest = numbers.stream()
                .distinct() // Remove duplicates
                .sorted(Comparator.reverseOrder()) // Sort the stream in descending order
                .skip(1) // Skip the largest number
                .findFirst(); // Find the second largest number

        // Displaying the second largest number
        secondLargest.ifPresent(number -> System.out.println("Second Largest Number: " + number));
    }
}