package com.java8.CapgeminiFirst10;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public class N36_MissingNumberInList {
    public static void main(String[] args) {
        List<Integer> nums= Arrays.asList(1 ,7 ,9);

        ArrayList<Integer> result = new ArrayList<>();
        IntStream.rangeClosed(1, 10).filter(num -> !nums.contains(num)).forEach(result::add);
        System.out.println(result.toString());

        System.out.println("=========================================================");
        IntStream.rangeClosed(1, 10).filter(num -> !nums.contains(num)).forEach(System.out::println);
    }
}
