package com.java8.CapgeminiFirst10;

import java.util.HashMap;
import java.util.*;
import java.util.stream.Collectors;

public class FindKeyByValue18 {
    public static void main(String[] args) {
        Map<Integer,Integer> map = new HashMap<>();

        map.put(1,5);
        map.put(2,4);
        map.put(6,8);
        map.put(3,5);
        List<Integer> list=map.entrySet().stream().filter(m -> m.getValue() ==5).map(m ->m.getKey()).collect(Collectors.toList());
        System.out.println(list);
    }
}
