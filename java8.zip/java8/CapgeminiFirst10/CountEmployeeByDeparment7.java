package com.java8.CapgeminiFirst10;

import java.util.*;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class CountEmployeeByDeparment7 {
    public static void main(String[] args)
    {
        Employee1[] employees1 = {
                new Employee1("J", "Red", 51000, "IT"),
                new Employee1("A", "Green", 71600, "IT"),
                new Employee1("M", "Black", 35187.5, "Sales"),
                new Employee1("K", "Yellow", 47100.77, "Marketing"),
                new Employee1("L", "Pink", 62001, "IT"),
                new Employee1("D", "Blue", 32001, "Sales"),
                new Employee1("W", "Brown", 42361.4, "Marketing")};

        // get List view of the Employees
        List<Employee1> list = Arrays.asList(employees1);

        // display all Employees
        System.out.println("Complete Employee1 list:");
        list.stream().forEach(System.out::println);

        // count number of Employees in each department
        System.out.printf("%nCount of Employees by department:%n");
        Map<String, Long> employeeCountByDepartment = list.stream()
                        .collect(Collectors.groupingBy(Employee1::getDepartment,
                                TreeMap::new, Collectors.counting()));
        employeeCountByDepartment.forEach(
                (department, count) -> System.out.printf(
                        "%s has %d employee(s)%n", department, count));

    }
}
