package com.java8.CapgeminiFirst10;

public class DivideProgram2 {

    public static void main(String[] args) {

        Divide d = (n1,n2)-> n1/n2;

        System.out.println(d.divide(10,2));
    }
}

interface Divide{
    int divide(int n1,int n2);

}
