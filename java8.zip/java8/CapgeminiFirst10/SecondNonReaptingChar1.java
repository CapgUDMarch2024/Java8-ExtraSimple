package com.java8.CapgeminiFirst10;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

public class SecondNonReaptingChar1 {

    public static void main(String[] args) {

        String str = "nonreapting";

      Map<Character,Long> map= str.chars().mapToObj(m -> (char)m).collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()));
      System.out.println(map);

      Optional< Character> ch =map.entrySet().stream().filter(f -> f.getValue() ==1).map(m ->m.getKey()).skip(1).findFirst();
      System.out.println(ch.get());
    }
}
