package com.test.capgemini;

import java.util.HashMap;
import java.util.Map;

public class M3_FractionToDecimal {
    public static void main(String[] args) {
        int numerator = 1;
        int denominator = 7;
        System.out.println(fractionToDecimal(numerator, denominator));
    }

    public static String fractionToDecimal(int numerator, int denominator) {
        long num = Math.abs((long) numerator);
        long den = Math.abs((long) denominator);

        StringBuilder result = new StringBuilder();
        result.append(num / den);

        long remainder = num % den;
        if (remainder != 0) {
            result.append(".");
            Map<Long, Integer> map = new HashMap<>();
            while (remainder != 0) {
                if (map.containsKey(remainder)) {
                    int index = map.get(remainder);
                    result.insert(index, "(");
                    result.append(")");
                    break;
                }
//                    System.out.println(result.length());
                map.put(remainder, result.length());
                System.out.println(map);
                remainder *= 10;
                result.append(remainder / den);
                remainder %= den;
            }
        }

        if ((numerator < 0) ^ (denominator < 0)) {
            result.insert(0, "-");
        }

        return result.toString();
    }
}
