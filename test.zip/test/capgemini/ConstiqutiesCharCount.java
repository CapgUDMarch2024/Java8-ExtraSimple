package com.test.capgemini;

public class ConstiqutiesCharCount {

    public static void main(String args[]){
     String str="aabbbcc";
        getQuote(str);
    }
    public static String getQuote(String s) {
        String result = "";
        int count = 1;
        char prev = s.charAt(0);
        for (int i = 1; i < s.length(); i++) {
            char curr = s.charAt(i);
            if (curr == prev) {
                count++;
            } else {
                result += prev + "" + count;
                prev = curr;
                count = 1;
            }
        }
        result += prev + "" + count;
        System.out.println(result);
        return result;
    }
}
