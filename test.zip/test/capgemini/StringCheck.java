package com.test.capgemini;

public class StringCheck {
  public static void main(String args[]){
      String str = "aabbbccaa";

      char[] arr = str.toCharArray();

      int count = 0;

      int len = arr.length;// len =11;

      for (int i = 0; i < arr.length; i++) { //i= 2

          for (int j = i; j < arr.length; j++) {
              if (arr[i] == arr[j]) {
                  count++;
              } else {
                  i = j -1;// i =1;
                  break;
              }

          }
          if (len-1 != i) {   //Or  len -1 != i
              System.out.print(arr[i]);
              System.out.print(count);
              count = 0;
          }
      }

  }

}
