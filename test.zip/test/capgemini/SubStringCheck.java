package com.test.capgemini;

import java.util.HashMap;
import java.util.Map;

public class SubStringCheck {
    public static String canComposeStr(String str1, String str2) {
        Map<Character, Integer> freqMap = new HashMap<Character, Integer>();
        for (char ch : str1.toCharArray()) {
            freqMap.put(ch, freqMap.getOrDefault(ch, 0) + 1);
        }
        System.out.println(freqMap);
        for (char ch : str2.toCharArray()) {
            if (!freqMap.containsKey(ch) || freqMap.get(ch) < 1) {
                return "No";
            }
            freqMap.put(ch, freqMap.get(ch) - 1);
        }
        return "Yes";
    }

    public static void main(String[] args) {
        String str1 = "abcdef";
        String str2 = "abcde";
        System.out.println(canComposeStr(str1, str2)); // Output: Yes
    }
}
