package com.test.capgemini;

import java.util.Scanner;

public class PanagramMissingCharacter {
	static String missingPangram(String input){
        String result = "";
        input = input.toLowerCase();
        char ch = 'a';
        for (int i = 0; i < 26; i++) {
            if(!input.contains(String.valueOf(ch))){
                result+=ch;
            }
            ch+=1;
        }
        return result;
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan =new Scanner(System.in);
		String str=scan.nextLine();
		System.out.println(missingPangram(str));

	}

}
