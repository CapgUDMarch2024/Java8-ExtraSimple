package com.test.capgemini;

import java.util.Arrays;

public class M5_maxOccurringCharInString {
    //Function to find Maximum Occurring Character
    static String maxOccurringChar(String str) {
        char ans = str.charAt(0);
        int i, curr_freq = 1, max_freq = 0;
        for (i = 1; i < str.length(); i++) {
            if (str.charAt(i) == str.charAt(i - 1)) {
                curr_freq++;
            }
            else {
                if (max_freq < curr_freq) {
                    max_freq = curr_freq;
                    ans = str.charAt(i - 1);
                }
                curr_freq = 1;
            }
        }
        if (max_freq < curr_freq) {
            max_freq = curr_freq;
            ans = str.charAt(i - 1);
        }
        return ans+""+max_freq;
    }

    public static void main(String[] args) {
        String str = "vivekkumarsinghii";
        //convert to character array
        char charArr[] = str.toCharArray();
        //sort the character array
        Arrays.sort(charArr);
        //sorted character array converted back to string
        str = new String(charArr);
        System.out.println("Maximum Occurring Character is " + maxOccurringChar(str));
    }
}
