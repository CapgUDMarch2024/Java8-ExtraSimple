package com.test.capgemini;

public class S17_NumerologyAlphabet {
	public static int getCode(char c){
        switch (c) {
        case 'A':
        case 'I':
        case 'J':
        case 'Q':
        case 'Y':
            return 1;
        case 'B':
        case 'K':
        case 'R':
            return 2;
        case 'C':
        case 'G':
        case 'L':
        case 'S':
            return 3;
        case 'D':
        case 'M':
        case 'T':
            return 4;
        case 'E':
        case 'H':
        case 'N':
        case 'X':
            return 5;
        case 'U':
        case 'V':
        case 'W':
            return 6;
        case 'O':
        case 'Z':
            return 7;
        case 'F':
        case 'P':
            return 8;
        default:
            return 0;
        }
    }
    public static int getNumerologySum(String s){
        int sum=0;
        for(char c: s.toCharArray())
            sum+=getCode(c);
        return sum;
    }
    public static void main(String[] args) {
        System.out.println(getNumerologySum("VIVEK"));
        System.out.println(getNumerologySum("S. KANAPATHY"));
        System.out.println(getNumerologySum("R RAJKUMAR"));
    }
}
