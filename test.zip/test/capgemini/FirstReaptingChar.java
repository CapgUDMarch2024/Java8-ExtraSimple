package com.test.capgemini;

import java.util.HashSet;
import java.util.Set;

public class FirstReaptingChar {
    public static void main(String[] args) {

        String str = "apple";

        getQuote(str);

    }

    public static void getQuote(String str) {

        char[] arr = str.toCharArray();

        Set<Character> st = new HashSet<Character>();

        for (int i = 0; i < arr.length; i++) {

            if (!st.add(arr[i])) {
                System.out.println(arr[i]);
                break;

            }

        }

    }
}
